import React from "react";

const shapes = { round: "rounded-[10px]" } as const;
const variants = {
  fill: {
    gray_900: "bg-gray-900 text-white-A700",
    blue_A200: "bg-blue-A200 text-white-A700",
  },
  outline: {
    blue_gray_500_01: "border border-blue_gray-500_01 border-solid",
    white_A700: "border border-solid border-white-A700 text-white-A700",
    blue_gray_500: "border border-blue_gray-500 border-solid text-white-A700",
  },
} as const;
const sizes = { xs: "p-3" } as const;

export type ButtonProps = Omit<
  React.DetailedHTMLProps<
    React.ButtonHTMLAttributes<HTMLButtonElement>,
    HTMLButtonElement
  >,
  "onClick"
> &
  Partial<{
    className: string;
    shape: keyof typeof shapes;
    variant: keyof typeof variants;
    size: keyof typeof sizes;
    color: string;
    leftIcon: React.ReactNode;
    rightIcon: React.ReactNode;
    onClick: () => void;
  }>;

const Button: React.FC<React.PropsWithChildren<ButtonProps>> = ({
  children,
  className = "",
  leftIcon,
  rightIcon,
  shape = "",
  size = "",
  variant = "",
  color = "",
  ...restProps
}) => {
  return (
    <button
      className={`${className} ${(shape && shapes[shape]) || ""} ${
        (size && sizes[size]) || ""
      } ${(variant && variants[variant]?.[color]) || ""}`}
      {...restProps}
    >
      {!!leftIcon && leftIcon}
      {children}
      {!!rightIcon && rightIcon}
    </button>
  );
};

export { Button };
