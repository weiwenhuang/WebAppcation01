import React from "react";

import { Sidebar } from "react-pro-sidebar";

import { Button, Img, Text } from "components";

type Sidebar1Props = React.DetailedHTMLProps<
  React.HTMLAttributes<HTMLDivElement>,
  HTMLDivElement
> &
  Partial<{}>;

const Sidebar1: React.FC<Sidebar1Props> = (props) => {
  return (
    <>
      <Sidebar className={props.className}>
        <Text
          className="ml-14 md:ml-[0] mr-[72px] mt-[17px] sm:text-[31px] md:text-[33px] text-[35px] text-blue-A200"
          size="txtDMSansBold35"
        >
          Linked Lists
        </Text>
        <div className="flex flex-col items-center justify-start md:ml-[0] ml-[54px] mr-[177px] mt-[17px]">
          <Text className="text-white-A700 text-xl" size="txtDMSansBold20">
            Variations
          </Text>
        </div>
        <Button
          className="cursor-pointer flex items-center justify-center min-w-[198px] md:ml-[0] ml-[55px] mr-[76px] mt-[9px]"
          rightIcon={
            <Img
              className="h-6 mb-px ml-2.5"
              src="images/img_checkmark.svg"
              alt="checkmark"
            />
          }
          shape="round"
          color="blue_A200"
          size="xs"
          variant="fill"
        >
          <div className="font-bold font-dmsans text-[17px] text-center">
            Singly linked list
          </div>
        </Button>
        <div className="flex flex-col items-center justify-start md:ml-[0] ml-[54px] mr-[166px] mt-[65px]">
          <Text className="text-white-A700 text-xl" size="txtDMSansBold20">
            Operations
          </Text>
        </div>
        <Button
          className="cursor-pointer flex items-center justify-center min-w-[197px] md:ml-[0] ml-[54px] mr-[78px] mt-[7px]"
          leftIcon={
            <Img
              className="h-[25px] mr-2.5"
              src="images/img_edit.svg"
              alt="edit"
            />
          }
          shape="round"
          color="blue_gray_500"
          size="xs"
          variant="outline"
        >
          <div className="font-bold font-dmsans text-[17px] text-center">
            Create
          </div>
        </Button>
        <Button
          className="cursor-pointer flex items-center justify-center min-w-[197px] md:ml-[0] ml-[54px] mr-[78px] mt-2"
          leftIcon={
            <Img
              className="h-[25px] mr-2.5"
              src="images/img_icons8plus.svg"
              alt="icons8:plus"
            />
          }
          shape="round"
          color="blue_gray_500"
          size="xs"
          variant="outline"
        >
          <div className="font-bold font-dmsans text-[17px] text-center">
            Insert
          </div>
        </Button>
        <Button
          className="cursor-pointer flex items-center justify-center min-w-[197px] md:ml-[0] ml-[54px] mr-[78px] mt-2"
          leftIcon={
            <Img
              className="h-5 mt-0.5 mb-px mr-[5px]"
              src="images/img_charmsearch.svg"
              alt="charm:search"
            />
          }
          shape="round"
          color="blue_A200"
          size="xs"
          variant="fill"
        >
          <div className="font-bold font-dmsans text-[17px] text-center">
            Search
          </div>
        </Button>
        <Button
          className="cursor-pointer flex items-center justify-center min-w-[197px] md:ml-[0] ml-[54px] mr-[78px] mt-2"
          leftIcon={
            <Img
              className="h-5 mt-0.5 mb-px mr-[5px]"
              src="images/img_trash.svg"
              alt="trash"
            />
          }
          shape="round"
          color="blue_gray_500"
          size="xs"
          variant="outline"
        >
          <div className="font-bold font-dmsans text-[17px] text-center">
            Delete
          </div>
        </Button>
        <div className="flex flex-col items-start justify-start md:ml-[0] ml-[55px] mr-[25px] mt-[63px] w-[76%]">
          <div className="flex flex-col items-center justify-start">
            <Text className="text-white-A700 text-xl" size="txtDMSansBold20">
              Playback
            </Text>
          </div>
          <div className="flex flex-col items-center justify-start mt-[21px]">
            <Text
              className="text-[17px] text-white-A700"
              size="txtDMSansBold17"
            >
              Speed
            </Text>
          </div>
          <Img
            className="h-[13px] mt-[5px]"
            src="images/img_group1000006191.svg"
            alt="group1000006191"
          />
          <Img
            className="h-[29px] ml-2.5 md:ml-[0] mt-[23px]"
            src="images/img_group1000006198.svg"
            alt="group1000006198"
          />
        </div>
        <div className="flex flex-col items-center justify-start md:ml-[0] ml-[55px] mr-[219px] mt-[60px]">
          <Text className="text-white-A700 text-xl" size="txtDMSansBold20">
            Learn
          </Text>
        </div>
        <Button
          className="cursor-pointer flex items-center justify-center min-w-[197px] md:ml-[0] ml-[55px] mr-[77px] mt-2"
          leftIcon={
            <Img
              className="h-[25px] mr-2.5"
              src="images/img_edit.svg"
              alt="edit"
            />
          }
          shape="round"
          color="blue_gray_500_01"
          size="xs"
          variant="outline"
        >
          <div className="!text-white-A700 font-bold font-dmsans text-[17px] text-center">
            Practice
          </div>
        </Button>
        <Button
          className="cursor-pointer flex items-center justify-center mb-[157px] min-w-[197px] md:ml-[0] ml-[55px] mr-[77px] mt-2"
          leftIcon={
            <Img
              className="h-6 mr-2.5"
              src="images/img_arrowdown.svg"
              alt="arrow_down"
            />
          }
          shape="round"
          color="blue_gray_500_01"
          size="xs"
          variant="outline"
        >
          <div className="!text-white-A700 font-bold font-dmsans text-[17px] text-center">
            Learn
          </div>
        </Button>
      </Sidebar>
    </>
  );
};

Sidebar1.defaultProps = {};

export default Sidebar1;
