import React from "react";

import { Button, Img, Input, Line, Text } from "components";
import Sidebar1 from "components/Sidebar1";

const StructureBasePage: React.FC = () => {
  return (
    <>
      <div className="bg-gray-900 flex flex-col font-dmsans items-center justify-start mx-auto w-full">
        <div className="flex flex-col items-center justify-start w-full">
          <div className="flex flex-col items-center justify-start w-full">
            <div className="bg-gray-900_01 flex md:flex-col flex-row md:gap-5 items-start justify-start p-[17px] w-full">
              <Text
                className="md:ml-[0] ml-[82px] md:mt-0 mt-[18px] md:text-3xl sm:text-[28px] text-[32px] text-center text-white-A700"
                size="txtPoppinsBold32"
              >
                <span className="text-white-A700 font-poppins font-bold">
                  Comp
                </span>
                <span className="text-blue-A200 font-poppins font-bold">
                  Sci
                </span>
                <span className="text-white-A700 font-poppins font-bold">
                  Lib
                </span>
              </Text>
              <div className="flex md:flex-1 md:flex-col flex-row font-dmsans gap-[17px] items-start justify-start md:ml-[0] ml-[33px] md:mt-0 mt-4 md:px-5 w-auto md:w-full">
                <div className="flex flex-row gap-[6.67px] items-start justify-start px-[3px] py-[10.01px] w-auto">
                  <Text
                    className="text-center text-white-A700 text-xl w-auto"
                    size="txtDMSansBold20"
                  >
                    Courses
                  </Text>
                  <Img
                    className="h-6 w-6"
                    src="images/img_checkmark.svg"
                    alt="checkmark"
                  />
                </div>
                <div className="flex flex-col items-start justify-start px-[3px] py-[10.01px] w-auto">
                  <Text
                    className="text-center text-white-A700 text-xl w-auto"
                    size="txtDMSansBold20"
                  >
                    AI Homework Help
                  </Text>
                </div>
                <div className="flex flex-col items-start justify-start px-[3px] py-[10.01px] w-auto">
                  <Text
                    className="text-center text-white-A700 text-xl w-auto"
                    size="txtDMSansBold20"
                  >
                    Roadmaps
                  </Text>
                </div>
                <div className="flex flex-col items-start justify-start px-[3px] py-[10.01px] w-auto">
                  <Text
                    className="text-center text-white-A700 text-xl w-auto"
                    size="txtDMSansBold20"
                  >
                    Discord
                  </Text>
                </div>
                <div className="flex flex-col items-start justify-start px-[3px] py-[10.01px] w-auto">
                  <Text
                    className="text-center text-white-A700 text-xl w-auto"
                    size="txtDMSansBold20"
                  >
                    Contact
                  </Text>
                </div>
              </div>
              <Img
                className="h-5 ml-1.5 md:ml-[0] md:mt-0 mt-7 w-5"
                src="images/img_search.svg"
                alt="search"
              />
              <Button
                className="cursor-pointer font-bold font-dmsans min-w-[94px] md:ml-[0] ml-[520px] md:mt-0 mt-4 text-[17px] text-center"
                shape="round"
                color="white_A700"
                size="xs"
                variant="outline"
              >
                Sign Up
              </Button>
              <Button
                className="cursor-pointer font-bold font-dmsans mb-[3px] min-w-[86px] ml-6 md:ml-[0] md:mt-0 mt-4 text-[17px] text-center"
                shape="round"
                color="blue_A200"
                size="xs"
                variant="fill"
              >
                Sign In
              </Button>
            </div>
          </div>
          <div className="flex md:flex-col flex-row md:gap-10 items-center justify-between w-full">
            <div className="flex md:px-5 relative w-[31%] md:w-full">
              <div className="h-[1046px] my-auto w-3/5">
                <Sidebar1 className="!sticky !w-[329px] bg-gray-900_02 flex h-screen md:hidden inset-[0] justify-center m-auto overflow-auto top-[0]" />
                <Line className="absolute bg-blue_gray-500 h-px inset-x-[0] mx-auto top-[20%] w-[99%]" />
              </div>
              <Line className="bg-blue_gray-500 h-px ml-[undefinedpx] my-auto w-[58%] z-[1]" />
              <Line className="bg-blue_gray-500 h-px mb-[321px] ml-[undefinedpx] mt-auto w-[58%] z-[1]" />
              <div className="h-[184px] md:h-[375px] ml-[-65px] mt-[193px] w-[53%] z-[1]">
                <div className="md:h-[182px] h-[184px] m-auto w-full">
                  <div className="absolute bg-gray-900_02 border border-blue_gray-500 border-solid flex flex-col gap-2 h-full inset-y-[0] items-center justify-start my-auto p-[18px] right-[0] rounded-md w-[95%]">
                    <div className="flex flex-col items-center justify-start">
                      <Text
                        className="text-2xl md:text-[22px] text-white-A700 sm:text-xl"
                        size="txtDMSansBold24WhiteA700"
                      >
                        Nodes
                      </Text>
                    </div>
                    <div className="flex flex-col gap-2.5 items-center justify-start mb-0.5 w-[98%] md:w-full">
                      <Input
                        name="button"
                        placeholder="17, 28, 32, 5, 14"
                        className="font-bold p-0 placeholder:text-white-A700 text-[17px] text-left w-full"
                        wrapClassName="w-full"
                      ></Input>
                      <div className="bg-green-300 flex flex-row items-center justify-center px-4 py-3 rounded-[10px] w-[237px]">
                        <Text
                          className="text-[17px] text-center text-white-A700 w-auto"
                          size="txtDMSansBold17"
                        >
                          Add
                        </Text>
                        <Img
                          className="h-[22px] w-[22px]"
                          src="images/img_arrowright.svg"
                          alt="arrowright"
                        />
                      </div>
                    </div>
                  </div>
                  <Img
                    className="absolute h-[39px] left-[0] top-[24%]"
                    src="images/img_computer.svg"
                    alt="computer"
                  />
                </div>
                <div className="absolute bg-gray-900_02 h-[61px] left-[6%] top-[20%] w-[6%]"></div>
              </div>
            </div>
            <div className="flex md:flex-1 flex-col md:gap-10 gap-[139px] justify-start md:px-5 w-3/5 md:w-full">
              <Button
                className="cursor-pointer flex items-center justify-center min-w-[108px] md:ml-[0] ml-[956px]"
                leftIcon={
                  <Img
                    className="h-[22px] mr-[5px] my-px"
                    src="images/img_search_white_a700.svg"
                    alt="search"
                  />
                }
                shape="round"
                color="blue_gray_500"
                size="xs"
                variant="outline"
              >
                <div className="font-bold text-[17px] text-center">Reset</div>
              </Button>
              <div className="flex flex-col items-start justify-start w-full">
                <div className="flex md:flex-col flex-row md:gap-5 items-center justify-start w-[55%] md:w-full">
                  <Text
                    className="flex h-[75px] items-center justify-center outline outline-[0.5px] outline-white-A700 sm:px-5 rounded-[37px] md:text-2xl sm:text-[22px] text-[26px] text-center text-white-A700 w-[75px]"
                    size="txtDMSansBold26"
                  >
                    17
                  </Text>
                  <Line className="bg-white-A700 h-[3px] ml-0.5 md:ml-[0] md:mt-0 my-9 w-[9%]" />
                  <Text
                    className="flex h-[75px] items-center justify-center md:ml-[0] ml-[3px] outline outline-[0.5px] outline-white-A700 sm:px-5 rounded-[37px] md:text-2xl sm:text-[22px] text-[26px] text-center text-white-A700 w-[75px]"
                    size="txtDMSansBold26"
                  >
                    28
                  </Text>
                  <Line className="bg-white-A700 h-[3px] ml-0.5 md:ml-[0] md:mt-0 my-9 w-[9%]" />
                  <Text
                    className="flex h-[75px] items-center justify-center md:ml-[0] ml-[3px] outline outline-[0.5px] outline-white-A700 sm:px-5 rounded-[37px] md:text-2xl sm:text-[22px] text-[26px] text-center text-white-A700 w-[75px]"
                    size="txtDMSansBold26"
                  >
                    32
                  </Text>
                  <Line className="bg-white-A700 h-[3px] md:ml-[0] ml-[3px] md:mt-0 my-9 w-[9%]" />
                  <Text
                    className="flex h-[75px] items-center justify-center md:ml-[0] ml-[3px] outline outline-[0.5px] outline-white-A700 sm:px-5 rounded-[37px] md:text-2xl sm:text-[22px] text-[26px] text-center text-white-A700 w-[75px]"
                    size="txtDMSansBold26"
                  >
                    5
                  </Text>
                  <Line className="bg-white-A700 h-[3px] ml-0.5 md:ml-[0] md:mt-0 my-9 w-[9%]" />
                  <Text
                    className="flex h-[75px] items-center justify-center md:ml-[0] ml-[3px] outline outline-[0.5px] outline-white-A700 sm:px-5 rounded-[37px] md:text-2xl sm:text-[22px] text-[26px] text-center text-white-A700 w-[75px]"
                    size="txtDMSansBold26"
                  >
                    14
                  </Text>
                </div>
                <div className="flex flex-row sm:gap-10 items-center justify-between ml-1 md:ml-[0] mt-[7px] w-[53%] md:w-full">
                  <Text
                    className="text-[17px] text-center text-red-400"
                    size="txtDMSansBold17Red400"
                  >
                    head[0]
                  </Text>
                  <Text
                    className="text-[17px] text-center text-red-400"
                    size="txtDMSansBold17Red400"
                  >
                    tail[5]
                  </Text>
                </div>
                <div className="flex md:flex-col flex-row font-courierprime gap-[7px] items-center justify-end md:ml-[0] ml-[466px] mt-[388px] w-[58%] md:w-full">
                  <div className="bg-gray-900_02 border border-blue_gray-500 border-solid h-[283px] md:h-[81px] py-9 relative w-[92%] md:w-full">
                    <div className="absolute bg-blue_gray-900 h-[63px] inset-x-[0] mx-auto top-[27%] w-full"></div>
                    <Text
                      className="absolute leading-[135.00%] left-[7%] text-white-A700 text-xl top-[13%]"
                      size="txtCourierPrimeRegular20"
                    >
                      <>
                        if empty, return NOT_FOUND
                        <br />
                        return head.item
                      </>
                    </Text>
                  </div>
                  <div className="bg-blue_gray-900 flex flex-col items-center justify-center p-2.5 w-[8%] md:w-full">
                    <Img
                      className="h-6 my-[119px] w-6"
                      src="images/img_arrowright.svg"
                      alt="arrowright_One"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default StructureBasePage;
