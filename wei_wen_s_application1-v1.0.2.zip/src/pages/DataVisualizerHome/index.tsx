import React from "react";

import { Button, Img, Text } from "components";

const DataVisualizerHomePage: React.FC = () => {
  return (
    <>
      <div className="bg-gray-900 flex flex-col font-dmsans items-center justify-start mx-auto w-full">
        <div className="flex flex-col items-center justify-start w-full">
          <header className="flex flex-col items-center justify-center md:px-5 w-full">
            <div className="bg-gray-900_01 flex md:flex-col flex-row md:gap-5 items-center justify-center p-[17px] w-full">
              <div className="header-row mt-[18px]">
                <Text
                  className="md:text-3xl sm:text-[28px] text-[32px] text-center text-white-A700"
                  size="txtPoppinsBold32"
                >
                  <span className="text-white-A700 font-poppins font-bold">
                    Comp
                  </span>
                  <span className="text-blue-A200 font-poppins font-bold">
                    Sci
                  </span>
                  <span className="text-white-A700 font-poppins font-bold">
                    Lib
                  </span>
                </Text>
                <div className="mobile-menu">
                  <div></div>
                  <div></div>
                  <div></div>
                </div>
              </div>
              <div className="flex md:flex-col flex-row font-dmsans gap-[17px] sm:hidden items-start justify-start md:ml-[0] ml-[33px] w-auto">
                <div className="flex flex-row gap-[6.67px] items-start justify-start px-[3px] py-[10.01px] w-auto">
                  <Text
                    className="text-center text-white-A700 text-xl w-auto"
                    size="txtDMSansBold20"
                  >
                    Courses
                  </Text>
                  <Img
                    className="h-6 w-6"
                    src="images/img_checkmark.svg"
                    alt="checkmark"
                  />
                </div>
                <div className="flex flex-col items-start justify-start px-[3px] py-[10.01px] w-auto">
                  <Text
                    className="text-center text-white-A700 text-xl w-auto"
                    size="txtDMSansBold20"
                  >
                    AI Homework Help
                  </Text>
                </div>
                <div className="flex flex-col items-start justify-start px-[3px] py-[10.01px] w-auto">
                  <Text
                    className="text-center text-white-A700 text-xl w-auto"
                    size="txtDMSansBold20"
                  >
                    Roadmaps
                  </Text>
                </div>
                <div className="flex flex-col items-start justify-start px-[3px] py-[10.01px] w-auto">
                  <Text
                    className="text-center text-white-A700 text-xl w-auto"
                    size="txtDMSansBold20"
                  >
                    Discord
                  </Text>
                </div>
                <div className="flex flex-col items-start justify-start px-[3px] py-[10.01px] w-auto">
                  <Text
                    className="text-center text-white-A700 text-xl w-auto"
                    size="txtDMSansBold20"
                  >
                    Contact
                  </Text>
                </div>
              </div>
              <Img
                className="h-5 sm:hidden ml-1.5 md:ml-[0] w-5"
                src="images/img_search.svg"
                alt="search"
              />
              <Button
                className="cursor-pointer font-bold font-dmsans sm:hidden min-w-[94px] md:ml-[0] ml-[520px] text-[17px] text-center"
                shape="round"
                color="white_A700"
                size="xs"
                variant="outline"
              >
                Sign Up
              </Button>
              <Button
                className="cursor-pointer font-bold font-dmsans sm:hidden mb-[3px] min-w-[86px] ml-6 md:ml-[0] md:mt-0 mt-4 text-[17px] text-center"
                shape="round"
                color="blue_A200"
                size="xs"
                variant="fill"
              >
                Sign In
              </Button>
            </div>
          </header>
          <div className="flex flex-col items-center justify-start max-w-[1338px] mt-[102px] mx-auto md:px-5 w-full">
            <Text
              className="md:text-5xl text-7xl text-blue-A200 text-center"
              size="txtDMSansBold72"
            >
              Data Structure & Algorithm Visualizers
            </Text>
            <Text
              className="mt-[26px] md:text-2xl sm:text-[22px] text-[26px] text-center text-white-A700"
              size="txtDMSansBold26"
            >
              Visualizing Data Structures and Algorithms through animation.
            </Text>
            <div className="bg-white-A700 flex flex-row md:gap-10 gap-[420px] h-[71px] md:h-auto items-center justify-start max-w-[1079px] mt-[81px] sm:px-5 px-[39.81px] py-[19px] rounded-[19px] w-full">
              <Text
                className="text-2xl md:text-[22px] text-blue_gray-100 sm:text-xl w-auto"
                size="txtDMSansBold24"
              >
                Linked List
              </Text>
              <Img
                className="h-8 w-8"
                src="images/img_settings.svg"
                alt="settings"
              />
            </div>
          </div>
          <div className="md:gap-5 gap-8 grid sm:grid-cols-1 md:grid-cols-2 grid-cols-3 justify-center max-w-[1708px] min-h-[auto] mt-[114px] mx-auto md:px-5 w-full">
            <div className="bg-gray-900_02 border border-blue_gray-500 border-solid flex flex-1 flex-col gap-[33px] items-center justify-start pb-11 rounded-[22px] w-full">
              <div className="bg-blue_gray-900 border border-blue_gray-500 border-solid flex sm:flex-col flex-row sm:gap-10 items-center justify-between p-4 rounded-tl-[22px] rounded-tr-[22px] w-full">
                <Text
                  className="ml-4 sm:ml-[0] md:text-2xl sm:text-[22px] text-[26px] text-white-A700"
                  size="txtDMSansBold26"
                >
                  Linked Lists
                </Text>
                <div className="flex flex-row gap-[9px] items-center justify-center mr-[3px]">
                  <Button
                    className="cursor-pointer font-bold min-w-[78px] text-[17px] text-center"
                    shape="round"
                    color="blue_gray_500"
                    size="xs"
                    variant="outline"
                  >
                    stack
                  </Button>
                  <Button
                    className="cursor-pointer font-bold min-w-[85px] text-[17px] text-center"
                    shape="round"
                    color="blue_gray_500"
                    size="xs"
                    variant="outline"
                  >
                    queue
                  </Button>
                  <Button
                    className="cursor-pointer font-bold min-w-[90px] text-[17px] text-center"
                    shape="round"
                    color="blue_gray_500"
                    size="xs"
                    variant="outline"
                  >
                    doubly
                  </Button>
                </div>
              </div>
              <Img
                className="h-[262px] md:h-auto object-cover w-[82%]"
                src="images/img_image3.png"
                alt="imageThree"
              />
            </div>
            <div className="bg-gray-900_02 border border-blue_gray-500 border-solid flex flex-1 flex-col gap-[33px] items-center justify-start pb-11 rounded-[22px] w-full">
              <div className="bg-blue_gray-900 border border-blue_gray-500 border-solid flex sm:flex-col flex-row sm:gap-10 items-center justify-between p-4 rounded-tl-[22px] rounded-tr-[22px] w-full">
                <Text
                  className="ml-4 sm:ml-[0] md:text-2xl sm:text-[22px] text-[26px] text-white-A700"
                  size="txtDMSansBold26"
                >
                  Linked Lists
                </Text>
                <div className="flex flex-row gap-[9px] items-center justify-center mr-[3px]">
                  <Button
                    className="cursor-pointer font-bold min-w-[78px] text-[17px] text-center"
                    shape="round"
                    color="blue_gray_500"
                    size="xs"
                    variant="outline"
                  >
                    stack
                  </Button>
                  <Button
                    className="cursor-pointer font-bold min-w-[85px] text-[17px] text-center"
                    shape="round"
                    color="blue_gray_500"
                    size="xs"
                    variant="outline"
                  >
                    queue
                  </Button>
                  <Button
                    className="cursor-pointer font-bold min-w-[90px] text-[17px] text-center"
                    shape="round"
                    color="blue_gray_500"
                    size="xs"
                    variant="outline"
                  >
                    doubly
                  </Button>
                </div>
              </div>
              <Img
                className="h-[262px] md:h-auto object-cover w-[82%]"
                src="images/img_image3.png"
                alt="imageThree"
              />
            </div>
            <div className="bg-gray-900_02 border border-blue_gray-500 border-solid flex flex-1 flex-col gap-[33px] items-center justify-start pb-11 rounded-[22px] w-full">
              <div className="bg-blue_gray-900 border border-blue_gray-500 border-solid flex sm:flex-col flex-row sm:gap-10 items-center justify-between p-4 rounded-tl-[22px] rounded-tr-[22px] w-full">
                <Text
                  className="ml-4 sm:ml-[0] md:text-2xl sm:text-[22px] text-[26px] text-white-A700"
                  size="txtDMSansBold26"
                >
                  Linked Lists
                </Text>
                <div className="flex flex-row gap-[9px] items-center justify-center mr-[3px]">
                  <Button
                    className="cursor-pointer font-bold min-w-[78px] text-[17px] text-center"
                    shape="round"
                    color="blue_gray_500"
                    size="xs"
                    variant="outline"
                  >
                    stack
                  </Button>
                  <Button
                    className="cursor-pointer font-bold min-w-[85px] text-[17px] text-center"
                    shape="round"
                    color="blue_gray_500"
                    size="xs"
                    variant="outline"
                  >
                    queue
                  </Button>
                  <Button
                    className="cursor-pointer font-bold min-w-[90px] text-[17px] text-center"
                    shape="round"
                    color="blue_gray_500"
                    size="xs"
                    variant="outline"
                  >
                    doubly
                  </Button>
                </div>
              </div>
              <Img
                className="h-[262px] md:h-auto object-cover w-[82%]"
                src="images/img_image3.png"
                alt="imageThree"
              />
            </div>
            <div className="bg-gray-900_02 border border-blue_gray-500 border-solid flex flex-1 flex-col gap-[33px] items-center justify-start pb-11 rounded-[22px] w-full">
              <div className="bg-blue_gray-900 border border-blue_gray-500 border-solid flex sm:flex-col flex-row sm:gap-10 items-center justify-between p-4 rounded-tl-[22px] rounded-tr-[22px] w-full">
                <Text
                  className="ml-4 sm:ml-[0] md:text-2xl sm:text-[22px] text-[26px] text-white-A700"
                  size="txtDMSansBold26"
                >
                  Linked Lists
                </Text>
                <div className="flex flex-row gap-[9px] items-center justify-center mr-[3px]">
                  <Button
                    className="cursor-pointer font-bold min-w-[78px] text-[17px] text-center"
                    shape="round"
                    color="blue_gray_500"
                    size="xs"
                    variant="outline"
                  >
                    stack
                  </Button>
                  <Button
                    className="cursor-pointer font-bold min-w-[85px] text-[17px] text-center"
                    shape="round"
                    color="blue_gray_500"
                    size="xs"
                    variant="outline"
                  >
                    queue
                  </Button>
                  <Button
                    className="cursor-pointer font-bold min-w-[90px] text-[17px] text-center"
                    shape="round"
                    color="blue_gray_500"
                    size="xs"
                    variant="outline"
                  >
                    doubly
                  </Button>
                </div>
              </div>
              <Img
                className="h-[262px] md:h-auto object-cover w-[82%]"
                src="images/img_image3.png"
                alt="imageThree"
              />
            </div>
            <div className="bg-gray-900_02 border border-blue_gray-500 border-solid flex flex-1 flex-col gap-[33px] items-center justify-start pb-11 rounded-[22px] w-full">
              <div className="bg-blue_gray-900 border border-blue_gray-500 border-solid flex sm:flex-col flex-row sm:gap-10 items-center justify-between p-4 rounded-tl-[22px] rounded-tr-[22px] w-full">
                <Text
                  className="ml-4 sm:ml-[0] md:text-2xl sm:text-[22px] text-[26px] text-white-A700"
                  size="txtDMSansBold26"
                >
                  Linked Lists
                </Text>
                <div className="flex flex-row gap-[9px] items-center justify-center mr-[3px]">
                  <Button
                    className="cursor-pointer font-bold min-w-[78px] text-[17px] text-center"
                    shape="round"
                    color="blue_gray_500"
                    size="xs"
                    variant="outline"
                  >
                    stack
                  </Button>
                  <Button
                    className="cursor-pointer font-bold min-w-[85px] text-[17px] text-center"
                    shape="round"
                    color="blue_gray_500"
                    size="xs"
                    variant="outline"
                  >
                    queue
                  </Button>
                  <Button
                    className="cursor-pointer font-bold min-w-[90px] text-[17px] text-center"
                    shape="round"
                    color="blue_gray_500"
                    size="xs"
                    variant="outline"
                  >
                    doubly
                  </Button>
                </div>
              </div>
              <Img
                className="h-[262px] md:h-auto object-cover w-[82%]"
                src="images/img_image3.png"
                alt="imageThree"
              />
            </div>
            <div className="bg-gray-900_02 border border-blue_gray-500 border-solid flex flex-1 flex-col gap-[33px] items-center justify-start pb-11 rounded-[22px] w-full">
              <div className="bg-blue_gray-900 border border-blue_gray-500 border-solid flex sm:flex-col flex-row sm:gap-10 items-center justify-between p-4 rounded-tl-[22px] rounded-tr-[22px] w-full">
                <Text
                  className="ml-4 sm:ml-[0] md:text-2xl sm:text-[22px] text-[26px] text-white-A700"
                  size="txtDMSansBold26"
                >
                  Linked Lists
                </Text>
                <div className="flex flex-row gap-[9px] items-center justify-center mr-[3px]">
                  <Button
                    className="cursor-pointer font-bold min-w-[78px] text-[17px] text-center"
                    shape="round"
                    color="blue_gray_500"
                    size="xs"
                    variant="outline"
                  >
                    stack
                  </Button>
                  <Button
                    className="cursor-pointer font-bold min-w-[85px] text-[17px] text-center"
                    shape="round"
                    color="blue_gray_500"
                    size="xs"
                    variant="outline"
                  >
                    queue
                  </Button>
                  <Button
                    className="cursor-pointer font-bold min-w-[90px] text-[17px] text-center"
                    shape="round"
                    color="blue_gray_500"
                    size="xs"
                    variant="outline"
                  >
                    doubly
                  </Button>
                </div>
              </div>
              <Img
                className="h-[262px] md:h-auto object-cover w-[82%]"
                src="images/img_image3.png"
                alt="imageThree"
              />
            </div>
          </div>
          <Img
            className="h-[380px] sm:h-auto mt-[114px] object-cover w-full"
            src="images/img_screencapturen.png"
            alt="screencapturen"
          />
        </div>
      </div>
    </>
  );
};

export default DataVisualizerHomePage;
