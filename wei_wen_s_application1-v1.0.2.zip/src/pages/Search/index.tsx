import React from "react";

import { Button, Img, Line, Text } from "components";
import Sidebar1 from "components/Sidebar1";

const SearchPage: React.FC = () => {
  return (
    <>
      <div className="bg-gray-900 flex flex-col font-dmsans items-center justify-start mx-auto w-full">
        <div className="flex flex-col items-center justify-start w-full">
          <div className="flex flex-col items-center justify-start w-full">
            <div className="bg-gray-900_01 flex md:flex-col flex-row md:gap-5 items-start justify-start p-[17px] w-full">
              <Text
                className="md:ml-[0] ml-[82px] md:mt-0 mt-[18px] md:text-3xl sm:text-[28px] text-[32px] text-center text-white-A700"
                size="txtPoppinsBold32"
              >
                <span className="text-white-A700 font-poppins font-bold">
                  Comp
                </span>
                <span className="text-blue-A200 font-poppins font-bold">
                  Sci
                </span>
                <span className="text-white-A700 font-poppins font-bold">
                  Lib
                </span>
              </Text>
              <div className="flex md:flex-1 md:flex-col flex-row font-dmsans gap-[17px] items-start justify-start md:ml-[0] ml-[33px] md:mt-0 mt-4 md:px-5 w-auto md:w-full">
                <div className="flex flex-row gap-[6.67px] items-start justify-start px-[3px] py-[10.01px] w-auto">
                  <Text
                    className="text-center text-white-A700 text-xl w-auto"
                    size="txtDMSansBold20"
                  >
                    Courses
                  </Text>
                  <Img
                    className="h-6 w-6"
                    src="images/img_checkmark.svg"
                    alt="checkmark"
                  />
                </div>
                <div className="flex flex-col items-start justify-start px-[3px] py-[10.01px] w-auto">
                  <Text
                    className="text-center text-white-A700 text-xl w-auto"
                    size="txtDMSansBold20"
                  >
                    AI Homework Help
                  </Text>
                </div>
                <div className="flex flex-col items-start justify-start px-[3px] py-[10.01px] w-auto">
                  <Text
                    className="text-center text-white-A700 text-xl w-auto"
                    size="txtDMSansBold20"
                  >
                    Roadmaps
                  </Text>
                </div>
                <div className="flex flex-col items-start justify-start px-[3px] py-[10.01px] w-auto">
                  <Text
                    className="text-center text-white-A700 text-xl w-auto"
                    size="txtDMSansBold20"
                  >
                    Discord
                  </Text>
                </div>
                <div className="flex flex-col items-start justify-start px-[3px] py-[10.01px] w-auto">
                  <Text
                    className="text-center text-white-A700 text-xl w-auto"
                    size="txtDMSansBold20"
                  >
                    Contact
                  </Text>
                </div>
              </div>
              <Img
                className="h-5 ml-1.5 md:ml-[0] md:mt-0 mt-7 w-5"
                src="images/img_search.svg"
                alt="search"
              />
              <Button
                className="cursor-pointer font-bold font-dmsans min-w-[94px] md:ml-[0] ml-[520px] md:mt-0 mt-4 text-[17px] text-center"
                shape="round"
                color="white_A700"
                size="xs"
                variant="outline"
              >
                Sign Up
              </Button>
              <Button
                className="cursor-pointer font-bold font-dmsans mb-[3px] min-w-[86px] ml-6 md:ml-[0] md:mt-0 mt-4 text-[17px] text-center"
                shape="round"
                color="blue_A200"
                size="xs"
                variant="fill"
              >
                Sign In
              </Button>
            </div>
          </div>
          <div className="flex md:flex-col flex-row md:gap-10 items-center justify-between w-full">
            <div className="h-[1046px] md:px-5 relative w-[31%] md:w-full">
              <Sidebar1 className="!sticky !w-[329px] bg-gray-900_02 flex h-screen md:hidden inset-y-[0] justify-start left-[0] my-auto overflow-auto top-[0]" />
              <Line className="absolute bg-blue_gray-500 h-px left-[1%] top-[20%] w-[58%]" />
              <Line className="absolute bg-blue_gray-500 h-px inset-y-[0] left-[1%] my-auto w-[58%]" />
              <Line className="absolute bg-blue_gray-500 bottom-[31%] h-px left-[1%] w-[58%]" />
              <div className="absolute flex flex-col items-center justify-start right-[0] top-[33%] w-[53%]">
                <div className="h-[143px] relative w-full">
                  <div className="h-[143px] m-auto w-full">
                    <div className="absolute bg-gray-900_02 border border-blue_gray-500 border-solid flex flex-col h-full inset-y-[0] items-center justify-start my-auto p-[13px] right-[0] rounded-md w-[95%]">
                      <div className="flex flex-col gap-[15px] items-center justify-start mb-2 w-[94%] md:w-full">
                        <div className="flex flex-row gap-[13px] items-center justify-between w-full">
                          <div className="flex flex-col items-center justify-start">
                            <Text
                              className="text-white-A700 text-xl"
                              size="txtDMSansBold20"
                            >
                              Value:
                            </Text>
                          </div>
                          <Button
                            className="cursor-pointer font-bold rounded text-[17px] text-center w-[165px]"
                            color="gray_900"
                            size="xs"
                            variant="fill"
                          >
                            17
                          </Button>
                        </div>
                        <div className="bg-green-300 flex flex-row items-center justify-center px-4 py-3 rounded-[10px] w-[237px]">
                          <Text
                            className="text-[17px] text-center text-white-A700 w-auto"
                            size="txtDMSansBold17"
                          >
                            Search
                          </Text>
                          <Img
                            className="h-5 w-5"
                            src="images/img_arrowright_white_a700.svg"
                            alt="arrowright"
                          />
                        </div>
                      </div>
                    </div>
                    <Img
                      className="absolute h-[39px] left-[0] top-[31%]"
                      src="images/img_computer.svg"
                      alt="computer"
                    />
                  </div>
                  <div className="absolute bg-gray-900_02 h-[61px] left-[6%] top-[26%] w-[6%]"></div>
                </div>
              </div>
            </div>
            <div className="flex md:flex-1 flex-col md:gap-10 gap-[161px] justify-start md:px-5 w-[59%] md:w-full">
              <Button
                className="cursor-pointer flex items-center justify-center min-w-[108px] md:ml-[0] ml-[930px]"
                leftIcon={
                  <Img
                    className="h-[22px] mr-[5px] my-px"
                    src="images/img_search_white_a700.svg"
                    alt="search"
                  />
                }
                shape="round"
                color="blue_gray_500"
                size="xs"
                variant="outline"
              >
                <div className="font-bold text-[17px] text-center">Reset</div>
              </Button>
              <div className="flex flex-col items-start justify-start w-full">
                <div className="flex md:flex-col flex-row md:gap-5 items-start justify-start w-[56%] md:w-full">
                  <Text
                    className="flex h-[75px] items-center justify-center outline outline-[3.5px] outline-blue-A200 sm:px-5 rounded-[37px] md:text-2xl sm:text-[22px] text-[26px] text-center text-white-A700 w-[75px]"
                    size="txtDMSansBold26"
                  >
                    17
                  </Text>
                  <Line className="bg-blue-A200 h-1.5 mb-8 ml-0.5 md:ml-[0] md:mt-0 mt-[37px] w-[9%]" />
                  <Text
                    className="flex h-[75px] items-center justify-center md:ml-[0] ml-[3px] outline outline-[3.5px] outline-blue-A200 sm:px-5 rounded-[37px] md:text-2xl sm:text-[22px] text-[26px] text-center text-white-A700 w-[75px]"
                    size="txtDMSansBold26"
                  >
                    28
                  </Text>
                  <Line className="bg-blue-A200 h-1.5 mb-8 ml-0.5 md:ml-[0] md:mt-0 mt-[37px] w-[9%]" />
                  <Text
                    className="bg-blue-A200 flex h-[75px] items-center justify-center md:ml-[0] ml-[3px] sm:px-5 rounded-[37px] md:text-2xl sm:text-[22px] text-[26px] text-center text-white-A700 w-[75px]"
                    size="txtDMSansBold26"
                  >
                    32
                  </Text>
                  <Line className="bg-white-A700 h-[3px] md:ml-[0] ml-[3px] md:mt-0 my-9 w-[9%]" />
                  <Text
                    className="flex h-[75px] items-center justify-center md:ml-[0] ml-[3px] outline outline-[0.5px] outline-white-A700 sm:px-5 rounded-[37px] md:text-2xl sm:text-[22px] text-[26px] text-center text-white-A700 w-[75px]"
                    size="txtDMSansBold26"
                  >
                    5
                  </Text>
                  <Line className="bg-white-A700 h-[3px] ml-0.5 md:ml-[0] md:mt-0 my-9 w-[9%]" />
                  <Text
                    className="flex h-[75px] items-center justify-center md:ml-[0] ml-[3px] outline outline-[0.5px] outline-white-A700 sm:px-5 rounded-[37px] md:text-2xl sm:text-[22px] text-[26px] text-center text-white-A700 w-[75px]"
                    size="txtDMSansBold26"
                  >
                    14
                  </Text>
                </div>
                <div className="flex flex-row sm:gap-10 items-center justify-between ml-1 md:ml-[0] mt-[7px] w-[55%] md:w-full">
                  <Text
                    className="text-[17px] text-center text-red-400"
                    size="txtDMSansBold17Red400"
                  >
                    head[0]
                  </Text>
                  <Text
                    className="text-[17px] text-center text-red-400"
                    size="txtDMSansBold17Red400"
                  >
                    tail[5]
                  </Text>
                </div>
                <div className="flex md:flex-col flex-row font-courierprime gap-[7px] items-center justify-end md:ml-[0] ml-[440px] mt-[366px] w-[59%] md:w-full">
                  <div className="bg-gray-900_02 border border-blue_gray-500 border-solid h-[283px] md:h-[81px] py-9 relative w-[92%] md:w-full">
                    <div className="absolute bg-blue_gray-900 h-[63px] inset-x-[0] mx-auto top-[27%] w-full"></div>
                    <Text
                      className="absolute leading-[135.00%] left-[7%] text-white-A700 text-xl top-[13%]"
                      size="txtCourierPrimeRegular20"
                    >
                      <>
                        if empty, return NOT_FOUND
                        <br />
                        return head.item
                      </>
                    </Text>
                  </div>
                  <div className="bg-blue_gray-900 flex flex-col items-center justify-center p-2.5 w-[8%] md:w-full">
                    <Img
                      className="h-6 my-[119px] w-6"
                      src="images/img_arrowright.svg"
                      alt="arrowright_One"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default SearchPage;
