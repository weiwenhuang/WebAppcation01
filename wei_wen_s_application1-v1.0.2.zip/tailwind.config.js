module.exports = {
  mode: "jit",
  content: [
    "./src/**/**/*.{js,ts,jsx,tsx,html,mdx}",
    "./src/**/*.{js,ts,jsx,tsx,html,mdx}",
  ],
  darkMode: "class",
  theme: {
    screens: { md: { max: "1050px" }, sm: { max: "550px" } },
    extend: {
      colors: {
        gray: { 900: "#0c131d", "900_02": "#111d2e", "900_01": "#0a1728" },
        green: { 300: "#6fcf97" },
        blue_gray: {
          100: "#d0d0d0",
          500: "#51669d",
          900: "#22324a",
          "500_01": "#52679d",
          "100_01": "#d9d9d9",
        },
        blue: { A200: "#378df2" },
        red: { 400: "#eb5757" },
        white: { A700: "#ffffff" },
      },
      fontFamily: {
        dmsans: "DM Sans",
        courierprime: "Courier Prime",
        poppins: "Poppins",
      },
    },
  },
  plugins: [require("@tailwindcss/forms")],
};
